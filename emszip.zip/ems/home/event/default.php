<?php
		if (isset($_GET['event_id'])) {
			$event_id = $_GET['event_id'];
		} else {
			$event_id = 0;
		}
		//echo "<p>Current Event ID: $event_id</p>";
	?>