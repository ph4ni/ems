<?php


	$conn = new mysqli('localhost', 'geon' , 'geon', 'formsdb');

	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}
	$helllo = $_POST['helllo'];
$noww = $_POST['noww'];
$bammee = $_POST['bammee'];

// insert data into database
$sql = "INSERT INTO nsfw (helllo,noww,bammee) VALUES ('$helllo','$noww','$bammee')";

if ($conn->query($sql) === FALSE) {
	echo "Error: " .$sql."$conn->error";
}

$id = $conn->insert_id;
if ($id) {
    include_once '../phpqrcode/qrlib.php';
    $qrCodePath = '../qrcodes/' . $id . '.png';
    QRcode::png($id, $qrCodePath);
    echo '<img src="' . $qrCodePath . '" alt="QR Code">';
}

echo "Data inserted successfully.";
?>